print("import: 'six'")
import six

